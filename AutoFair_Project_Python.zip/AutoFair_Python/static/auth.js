/* Shared header + helpers for Home, Sign Up, Login and Contact pages */
const AF={user:JSON.parse(localStorage.getItem('af_user')||'null'),tok:localStorage.getItem('af_tok')||''};
AF.save=d=>{localStorage.setItem('af_user',JSON.stringify(d.user));localStorage.setItem('af_tok',d.token)};
AF.logout=()=>{localStorage.removeItem('af_user');localStorage.removeItem('af_tok');location.href='index.html'};
AF.api=async(p,o={})=>{const h={'Content-Type':'application/json'};if(AF.tok)h.Authorization='Bearer '+AF.tok;
 const r=await fetch('/api'+p,{...o,headers:h,body:o.json?JSON.stringify(o.json):undefined});const d=await r.json().catch(()=>({}));
 if(!r.ok){const e=new Error(d.error||'Request failed');e.errors=d.errors;throw e}return d};
AF.esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
document.addEventListener('DOMContentLoaded',()=>{const h=document.getElementById('hdr');if(!h)return;
 h.className='top';h.innerHTML=`<div><span class="logo">🚗 AutoFair</span> &nbsp; <a href="index.html">Home</a><a href="app.html">Browse Cars</a><a href="app.html">Post Ad</a><a href="contact.html">Contact Us</a></div>
 <div>${AF.user?`${AF.esc(AF.user.name)} <button id="lo">Logout</button>`:'<a href="login.html">Sign In</a><a href="signup.html" class="btn p">Sign Up</a>'}</div>`;
 const b=document.getElementById('lo');if(b)b.onclick=AF.logout});
