"""AutoFair - Flask backend (Python) + MongoDB. Run:  python app.py   then open http://localhost:3000"""
import datetime
import os
import re
import sys
from functools import wraps

import jwt
from flask import Flask, g, jsonify, request, send_from_directory
from pymongo.errors import DuplicateKeyError
from werkzeug.exceptions import HTTPException
from werkzeug.security import check_password_hash, generate_password_hash

import db as database
import engine
import imaging
import validators as V
from db import col, next_id

BASE = os.path.dirname(os.path.abspath(__file__))
UPLOADS = os.path.join(BASE, "uploads")
os.makedirs(UPLOADS, exist_ok=True)
SECRET = os.getenv("JWT_SECRET", "dev-secret")
MAKES = {"Corolla": "Toyota", "Yaris": "Toyota", "Civic": "Honda", "City": "Honda",
         "Cultus": "Suzuki", "Alto": "Suzuki", "Sportage": "KIA"}

app = Flask(__name__, static_folder=os.path.join(BASE, "static"), static_url_path="")
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024 * 1024


# ---------------- helpers ----------------
@app.before_request
def load_user():
    g.user = None
    t = request.headers.get("Authorization", "").replace("Bearer ", "")
    if t:
        try:
            g.user = jwt.decode(t, SECRET, algorithms=["HS256"])
        except Exception:
            pass


def need(f):
    @wraps(f)
    def w(*a, **k):
        if not g.user:
            return jsonify(error="Please log in"), 401
        return f(*a, **k)
    return w


def admin_only(f):
    @wraps(f)
    def w(*a, **k):
        if not g.user or g.user.get("role") != "admin":
            return jsonify(error="Admin only"), 403
        return f(*a, **k)
    return w


def make_token(u):
    exp = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=7)
    return jwt.encode({"id": u["id"], "name": u["name"], "role": u["role"], "exp": exp}, SECRET, algorithm="HS256")


def bad(errors):
    return jsonify(error=next(iter(errors.values())), errors=errors), 400


def hashes_of(listing_id):
    return [p["phash"] for p in col("photos").find({"listing_id": listing_id})]


@app.errorhandler(Exception)
def on_error(e):
    if isinstance(e, HTTPException):
        return jsonify(error=e.description), e.code
    app.logger.exception(e)
    return jsonify(error=str(e)), 500


@app.get("/")
def home():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/uploads/<path:name>")
def uploaded(name):
    return send_from_directory(UPLOADS, name)


# ---------------- auth (FR-01) ----------------
@app.post("/api/register")
def register():
    d = request.get_json(silent=True) or {}
    errors = V.register({"name": d.get("name"), "email": d.get("email"), "password": d.get("password")})
    if errors:
        return bad(errors)
    u = {"id": next_id("users"), "name": d["name"].strip(), "email": d["email"].strip().lower(),
         "pass_hash": generate_password_hash(d["password"]), "role": "user"}
    try:
        col("users").insert_one(u)
    except DuplicateKeyError:
        return jsonify(error="Email already registered"), 400
    return jsonify(token=make_token(u), user={"id": u["id"], "name": u["name"], "role": u["role"]})


@app.post("/api/login")
def login():
    d = request.get_json(silent=True) or {}
    errors = V.login(d)
    if errors:
        return bad(errors)
    u = col("users").find_one({"email": str(d["email"]).strip().lower()})
    if not u or not check_password_hash(u["pass_hash"], str(d.get("password") or "")):
        return jsonify(error="Wrong email or password"), 401
    return jsonify(token=make_token(u), user={"id": u["id"], "name": u["name"], "role": u["role"]})


# ---------------- browse (FR-03, FR-04) ----------------
def _num(x):
    return int(x) if re.fullmatch(r"\d{1,9}", x or "") else None


@app.get("/api/listings")
def browse():
    a, q = request.args, {"status": {"$ne": "removed"}}
    for k in ("make", "model", "city"):
        if a.get(k):
            q[k] = a[k]
    minp, maxp, miny, maxy = (_num(a.get(k)) for k in ("minp", "maxp", "miny", "maxy"))
    if minp is not None or maxp is not None:
        q["price"] = {**({"$gte": minp} if minp is not None else {}), **({"$lte": maxp} if maxp is not None else {})}
    if miny is not None or maxy is not None:
        q["year"] = {**({"$gte": miny} if miny is not None else {}), **({"$lte": maxy} if maxy is not None else {})}
    order = {"pa": [("price", 1)], "pd": [("price", -1)]}.get(a.get("sort"), [("id", -1)])
    out = []
    for l in col("listings").find(q, {"_id": 0}).sort(order).limit(30):
        e, p = engine.evaluate(l), col("photos").find_one({"listing_id": l["id"]})
        out.append({"id": l["id"], "make": l["make"], "model": l["model"], "year": l["year"], "km": l["km"],
                    "price": l["price"], "city": l["city"], "thumb": p["file"] if p else None,
                    "rating": e["rating"], "review": l["status"] == "review"})
    return jsonify(out)


# ---------------- details (FR-06) with hidden phone (FR-09) ----------------
@app.get("/api/listings/<int:lid>")
def detail(lid):
    l = col("listings").find_one({"id": lid, "status": {"$ne": "removed"}}, {"_id": 0})
    if not l:
        return jsonify(error="Not found"), 404
    photos = list(col("photos").find({"listing_id": lid}))
    e = engine.evaluate(l, [p["phash"] for p in photos])
    contact, phone, u = "none", None, g.user
    if u and (u["role"] == "admin" or u["id"] == l.get("seller_id")):
        contact, phone = "approved", l["phone"]
    elif u:
        r = col("contact_requests").find_one({"listing_id": lid, "buyer_id": u["id"]})
        if r:
            contact = r["status"]
            phone = l["phone"] if contact == "approved" else None
    return jsonify(id=lid, make=l["make"], model=l["model"], year=l["year"], km=l["km"], price=l["price"],
                   city=l["city"], seller=l["seller"], review=l["status"] == "review",
                   photos=[p["file"] for p in photos], rating=e["rating"], median=e["median"], ratio=e["ratio"],
                   comps=e["comps"][:5], flags=[] if l["status"] == "approved" else e["flags"],
                   contact=contact, phone=phone)


# ---------------- post a listing with image analysis (FR-02, FR-08, FR-12, FR-13, FR-14) ----------------
@app.post("/api/listings")
@need
def create_listing():
    f = request.form.to_dict()
    photos = [(x.mimetype, x.read()) for x in request.files.getlist("photos")]
    o = request.files.get("odometer")
    odo = (o.mimetype, o.read()) if o else None
    errors = V.listing({**f, "photos": [{"type": t, "size": len(b)} for t, b in photos],
                        "odometer": [{"type": odo[0], "size": len(odo[1])}] if odo else []})
    if errors:
        return bad(errors)
    results = []
    for i, (_, data) in enumerate(photos):
        a = imaging.analyze(data)
        if not a["is_car"]:
            return jsonify(error=f"Photo {i + 1} does not appear to contain a car "
                                 f"(confidence {round(a['car_conf'] * 100)}%)."), 400
        results.append(a)
    odo_read = imaging.read_odometer(odo[1])
    l = {"seller_id": g.user["id"], "seller": g.user["name"], "make": MAKES.get(f["model"], "Other"),
         "model": f["model"], "year": int(f["year"]), "km": int(f["km"]), "price": int(f["price"]),
         "city": f["city"], "phone": re.sub(r"[\s-]", "", f["phone"]), "odo_read": odo_read}
    e = engine.evaluate(l, [r["phash"] for r in results])
    status = "review" if e["flags"] else "live"
    lid = next_id("listings")
    col("listings").insert_one({**l, "id": lid, "status": status, "flags": e["flags"],
                                "created": datetime.datetime.now(datetime.timezone.utc)})
    docs = []
    for i, r in enumerate(results):
        fn = f"{lid}-{i}.jpg"
        with open(os.path.join(UPLOADS, fn), "wb") as fh:
            fh.write(r["image"])
        docs.append({"listing_id": lid, "file": fn, "phash": r["phash"]})
    col("photos").insert_many(docs)
    return jsonify(id=lid, status=status, rating=e["rating"], median=e["median"], flags=e["flags"], odo_read=odo_read,
                   photo_notes=[{"photo": i + 1, "blurry": r["sharpness"] < 60, "low_res": r["width"] < 400,
                                 "plates_blurred": r["plates"]} for i, r in enumerate(results)])


# ---------------- Contact Us form ----------------
@app.post("/api/contact")
def contact_us():
    d = request.get_json(silent=True) or {}
    errors = V.contact(d)
    if errors:
        return bad(errors)
    col("contact_messages").insert_one({
        "id": next_id("messages"), "name": d["name"].strip(), "email": d["email"].strip(),
        "phone": re.sub(r"[\s-]", "", d.get("phone") or ""), "subject": d["subject"].strip(),
        "message": d["message"].strip(), "created": datetime.datetime.now(datetime.timezone.utc)})
    return jsonify(ok=True)


# ---------------- contact requests (FR-09) ----------------
@app.post("/api/listings/<int:lid>/contact")
@need
def request_contact(lid):
    if not col("listings").find_one({"id": lid}):
        return jsonify(error="Not found"), 404
    col("contact_requests").update_one({"listing_id": lid, "buyer_id": g.user["id"]},
                                       {"$setOnInsert": {"id": next_id("requests"), "status": "pending"}}, upsert=True)
    return jsonify(ok=True)


@app.get("/api/requests")
@need
def my_requests():
    adm = g.user["role"] == "admin"
    ls = list(col("listings").find({} if adm else {"seller_id": g.user["id"]},
                                   {"_id": 0, "id": 1, "make": 1, "model": 1, "year": 1}))
    rs = list(col("contact_requests").find({"listing_id": {"$in": [x["id"] for x in ls]}}).sort("id", -1))
    us = list(col("users").find({"id": {"$in": [r["buyer_id"] for r in rs]}}, {"_id": 0, "id": 1, "name": 1}))
    out = []
    for r in rs:
        l = next(x for x in ls if x["id"] == r["listing_id"])
        u = next((x for x in us if x["id"] == r["buyer_id"]), None)
        out.append({"id": r["id"], "status": r["status"], "make": l["make"], "model": l["model"],
                    "year": l["year"], "buyer": u["name"] if u else "?"})
    return jsonify(out)


@app.post("/api/requests/<int:rid>/approve")
@need
def approve_request(rid):
    r = col("contact_requests").find_one({"id": rid})
    l = r and col("listings").find_one({"id": r["listing_id"]})
    if not r or not l or (g.user["role"] != "admin" and l.get("seller_id") != g.user["id"]):
        return jsonify(error="Not allowed"), 403
    col("contact_requests").update_one({"id": rid}, {"$set": {"status": "approved"}})
    return jsonify(ok=True)


# ---------------- admin moderation + thresholds (FR-10, NFR-05) ----------------
@app.get("/api/admin/queue")
@need
@admin_only
def queue():
    out = []
    for l in col("listings").find({"status": "review"}, {"_id": 0}).sort("id", -1).limit(50):
        e = engine.evaluate(l, hashes_of(l["id"]))
        out.append({"id": l["id"], "title": f"{l['make']} {l['model']} {l['year']}", "price": l["price"],
                    "seller": l["seller"], "flags": e["flags"]})
    return jsonify(out)


@app.post("/api/admin/listings/<int:lid>/<act>")
@need
@admin_only
def moderate(lid, act):
    status = {"approve": "approved", "remove": "removed"}.get(act)
    if not status:
        return jsonify(error="Bad action"), 400
    col("listings").update_one({"id": lid}, {"$set": {"status": status}})
    return jsonify(ok=True)


@app.get("/api/admin/settings")
@need
@admin_only
def get_settings():
    return jsonify(engine.get_settings())


@app.put("/api/admin/settings")
@need
@admin_only
def put_settings():
    d = request.get_json(silent=True) or {}
    errors = V.settings(d)
    if errors:
        return bad(errors)
    upd = {k: int(d[k]) for k in ("low_pct", "km_year", "hash_dist", "odo_tol") if d.get(k) is not None}
    if upd:
        col("settings").update_one({"_id": "main"}, {"$set": upd})
    return jsonify(engine.get_settings())


# ---------------- database connection proof (for the lab screenshot) ----------------
@app.get("/api/db-status")
def db_status():
    database.client.admin.command("ping")
    names = sorted(database.db.list_collection_names())
    uri = re.sub(r"//.*@", "//", os.getenv("MONGO_URI", "mongodb://127.0.0.1:27017"))
    return jsonify(connected=True, type="MongoDB", database=database.db.name, server=uri,
                   time=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   collections=[{"name": n, "count": col(n).count_documents({})} for n in names])


if __name__ == "__main__":
    try:
        database.connect()
    except Exception as ex:
        print("Could not connect to MongoDB. Is it running? ->", ex)
        sys.exit(1)
    port = int(os.getenv("PORT", "3000"))
    print(f"AutoFair running on http://localhost:{port}")
    app.run(port=port, debug=False)
