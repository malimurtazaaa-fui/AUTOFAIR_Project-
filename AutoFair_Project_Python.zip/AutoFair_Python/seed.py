"""Fills MongoDB with an admin account and 300 demo listings (no photos). Safe to run again."""
import datetime
import random
import sys
from datetime import date

from werkzeug.security import generate_password_hash

import db as database
import engine
from db import col, next_id

M = {"Corolla": ("Toyota", 4200000), "Civic": ("Honda", 5500000), "City": ("Honda", 3800000),
     "Yaris": ("Toyota", 3900000), "Cultus": ("Suzuki", 2600000), "Alto": ("Suzuki", 2200000),
     "Sportage": ("KIA", 7500000)}
CITIES = ["Karachi", "Lahore", "Islamabad", "Rawalpindi", "Faisalabad"]


def main():
    database.connect()
    if not col("users").find_one({"email": "admin@autofair.pk"}):
        col("users").insert_one({"id": next_id("users"), "name": "Admin", "email": "admin@autofair.pk",
                                 "pass_hash": generate_password_hash("admin123"), "role": "admin"})
    if col("listings").count_documents({}) > 0:
        print("Listings already exist - nothing to seed.")
        return
    now, docs = date.today().year, []
    for i in range(300):
        model = random.choice(list(M))
        year = random.randint(2016, 2022)
        age = now - year
        km = max(8000, round((age * 12000 + (random.random() - .5) * 16000) / 1000) * 1000)
        price = round(M[model][1] * (1 + (year - 2018) * .06) * (1 - (km - age * 12000) / 450000)
                      * (.92 + random.random() * .16) / 10000) * 10000
        if i % 40 == 5:
            price = round(price * .55 / 10000) * 10000      # a few suspiciously cheap ads
        if i % 45 == 12:
            km = max(3000, age * 2500)                       # a few ads with impossible mileage
        phone = "03" + str(100000000 + (21 if i == 22 else i) * 7919)[:9]   # ads 21 and 22 share a phone
        docs.append({"id": next_id("listings"), "seller_id": None, "seller": f"Seller{i}", "make": M[model][0],
                     "model": model, "year": year, "km": km, "price": price, "city": random.choice(CITIES),
                     "phone": phone, "status": "live", "flags": [],
                     "created": datetime.datetime.now(datetime.timezone.utc)})
    col("listings").insert_many(docs)
    review = 0
    for l in docs:
        if engine.evaluate(l)["flags"]:
            col("listings").update_one({"id": l["id"]}, {"$set": {"status": "review"}})
            review += 1
    print(f"Seeded 300 listings ({review} flagged for review). Admin login: admin@autofair.pk / admin123")


if __name__ == "__main__":
    try:
        main()
    except Exception as ex:
        print("Seed failed. Is MongoDB running? ->", ex)
        sys.exit(1)
