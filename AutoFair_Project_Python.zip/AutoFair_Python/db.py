"""MongoDB connection. One shared client for the whole app (Singleton)."""
import os
from dotenv import load_dotenv
from pymongo import MongoClient, ReturnDocument

load_dotenv()
client = MongoClient(os.getenv("MONGO_URI", "mongodb://127.0.0.1:27017"), serverSelectionTimeoutMS=4000)
db = client[os.getenv("DB_NAME", "autofair")]


def col(name):
    return db[name]


def connect():
    """Check MongoDB is reachable, then create indexes and default settings."""
    client.admin.command("ping")  # raises an error if MongoDB is not running
    col("users").create_index("email", unique=True)
    col("listings").create_index("id", unique=True)
    col("listings").create_index([("model", 1), ("year", 1)])
    col("photos").create_index("listing_id")
    col("contact_requests").create_index([("listing_id", 1), ("buyer_id", 1)], unique=True)
    col("settings").update_one({"_id": "main"},
                               {"$setOnInsert": {"low_pct": 30, "km_year": 5000, "hash_dist": 10, "odo_tol": 5}},
                               upsert=True)


def next_id(name):
    """Auto-increment numbers (1, 2, 3...) so the website can use simple numeric ids."""
    r = col("counters").find_one_and_update({"_id": name}, {"$inc": {"seq": 1}}, upsert=True,
                                            return_document=ReturnDocument.AFTER)
    return r["seq"]
