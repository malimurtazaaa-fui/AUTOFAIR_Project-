# AutoFair – Used Car Listing and Price-Fairness Checker (Python + MongoDB)
Muhammad Ali Murtaza · F-24-BSSE-023 · SCD Lab · Section 5A

The whole backend is **Python (Flask)** with **MongoDB**. One program does everything: website, API, database,
price-fairness engine and image analysis (OpenCV, YOLO, Tesseract OCR). No Node.js needed.

## Requirements
- Python 3.10+ (https://python.org – tick "Add Python to PATH")
- MongoDB Community Server (https://www.mongodb.com/try/download/community). Tick **Install as a Service** and **Install MongoDB Compass**.
- Tesseract OCR program (Windows: https://github.com/UB-Mannheim/tesseract/wiki and add to PATH · Ubuntu: `sudo apt install tesseract-ocr`). Check: `tesseract --version`

## Run
```
python -m venv venv
venv\Scripts\activate            (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
copy .env.example .env           (Mac/Linux: cp .env.example .env)
python seed.py                   (admin account + 300 demo listings)
python app.py
```
Open http://localhost:3000 · Admin login: `admin@autofair.pk` / `admin123` (change it).
Database proof page for your screenshot: http://localhost:3000/db-status.html (also check Compass → `autofair`).

To skip the YOLO model download while testing: set `SKIP_CAR_CHECK=1` in `.env`.

## Files
| File | Purpose |
|---|---|
| `app.py` | Flask routes (login, listings, contact, admin, DB status) |
| `db.py` | MongoDB connection (shared client) |
| `engine.py` | Price-fairness rating + suspicious-ad rules |
| `imaging.py` | pHash, blur check, car check, plate blur, odometer OCR |
| `validators.py` | Server-side input validation |
| `seed.py` | Demo data |
| `static/` | Web pages: `index`, `signup`, `login`, `contact`, `app`, `db-status` (HTML/CSS) |

The pages use a little browser JavaScript (`static/validation.js`) for instant error messages; the same rules are checked again in Python (`validators.py`).

## Known limits
- Plate blurring uses OpenCV's Haar plate cascade (trained on other countries' plates); it may miss some Pakistani plates.
- OCR works best on a clear, straight dashboard photo; unreadable photos are flagged for admin review, not rejected.
- Demo listings have no photos; photos appear for ads you post.

## Optional: run the automated tests
```
pip install mongomock
python test_app.py
```
Uses a fake in-memory MongoDB, so it works even if MongoDB is not running.
