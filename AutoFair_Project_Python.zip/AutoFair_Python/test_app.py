"""Automated test of the whole backend using a fake in-memory MongoDB (pip install mongomock).
Run:  python test_app.py"""
import io, os, sys
os.environ["SKIP_CAR_CHECK"] = "1"          # no YOLO download during tests
import cv2, mongomock, numpy as np
import db as database
database.client = mongomock.MongoClient()   # swap the real MongoDB for an in-memory fake
database.db = database.client["autofair_test"]
database.connect()
import seed, app as appmod

seed.main()
c = appmod.app.test_client()
ok = True
def t(name, cond):
    global ok
    print(("PASS  " if cond else "FAIL  ") + name)
    ok = ok and bool(cond)

def png(draw=None, seed_=1, size=(480, 360)):
    rng = np.random.default_rng(seed_)
    img = rng.integers(0, 255, (size[1], size[0], 3), dtype=np.uint8)
    if draw: img = draw(img)
    return io.BytesIO(cv2.imencode(".png", img)[1].tobytes())
def odometer(txt):
    def d(_):
        im = np.full((200, 600, 3), 255, np.uint8)
        cv2.putText(im, txt, (40, 140), cv2.FONT_HERSHEY_SIMPLEX, 4, (0, 0, 0), 8)
        return im
    return png(d, size=(600, 200))

# --- auth & validation
r = c.post("/api/register", json={"name": "Ali Murtaza", "email": "Ali@Test.com", "password": "Strong123"})
t("register works", r.status_code == 200 and r.json["user"]["name"] == "Ali Murtaza")
tok = r.json["token"]; H = {"Authorization": "Bearer " + tok}
t("duplicate email rejected", c.post("/api/register", json={"name": "Ali", "email": "ali@test.com", "password": "Strong123"}).status_code == 400)
t("weak password rejected", c.post("/api/register", json={"name": "Ali", "email": "x@test.com", "password": "weak"}).status_code == 400)
t("login works (case-insensitive email)", c.post("/api/login", json={"email": "ALI@test.com", "password": "Strong123"}).status_code == 200)
t("wrong password rejected", c.post("/api/login", json={"email": "ali@test.com", "password": "Nope12345"}).status_code == 401)
# --- contact
t("contact message saved", c.post("/api/contact", json={"name": "Ali", "email": "a@b.co", "subject": "Hello", "message": "A long enough message."}).status_code == 200
  and database.col("contact_messages").count_documents({}) == 1)
t("short contact message rejected", c.post("/api/contact", json={"name": "Ali", "email": "a@b.co", "subject": "Hello", "message": "short"}).status_code == 400)
# --- browse
lst = c.get("/api/listings").json
t("browse returns 30 listings with ratings", len(lst) == 30 and all("rating" in x for x in lst))
t("price filter works", all(x["price"] <= 3000000 for x in c.get("/api/listings?maxp=3000000").json))
t("bad filter value ignored (no crash)", c.get("/api/listings?minp=abc&make[$ne]=x").status_code == 200)
d = c.get(f"/api/listings/{lst[0]['id']}").json
t("detail hides phone from visitors", d["phone"] is None and d["contact"] == "none")
# --- contact request flow
lid = lst[0]["id"]
t("contact request needs login", c.post(f"/api/listings/{lid}/contact").status_code == 401)
c.post(f"/api/listings/{lid}/contact", headers=H)
t("request is pending", c.get(f"/api/listings/{lid}", headers=H).json["contact"] == "pending")
adm = c.post("/api/login", json={"email": "admin@autofair.pk", "password": "admin123"}).json
AH = {"Authorization": "Bearer " + adm["token"]}
rq = c.get("/api/requests", headers=AH).json
t("admin sees the request", len(rq) == 1)
c.post(f"/api/requests/{rq[0]['id']}/approve", headers=AH)
t("phone visible after approval", c.get(f"/api/listings/{lid}", headers=H).json["phone"] is not None)
# --- admin
t("non-admin blocked from queue", c.get("/api/admin/queue", headers=H).status_code == 403)
q = c.get("/api/admin/queue", headers=AH).json
t("admin queue has flagged ads with reasons", len(q) > 0 and all(x["flags"] for x in q))
c.post(f"/api/admin/listings/{q[0]['id']}/approve", headers=AH)
t("approved ad leaves the queue", all(x["id"] != q[0]["id"] for x in c.get("/api/admin/queue", headers=AH).json))
t("settings update works", c.put("/api/admin/settings", json={"low_pct": 40}, headers=AH).json["low_pct"] == 40)
t("invalid settings rejected", c.put("/api/admin/settings", json={"low_pct": 99}, headers=AH).status_code == 400)
c.put("/api/admin/settings", json={"low_pct": 30}, headers=AH)
# --- post listing with images (real OpenCV + Tesseract)
def post(photos, odo, **kw):
    f = {"model": "Corolla", "year": "2019", "km": "60000", "price": "4300000", "city": "Karachi", "phone": "03001234567"}; f.update(kw)
    data = {**f, "photos": [(p, f"p{i}.png", "image/png") for i, p in enumerate(photos)], "odometer": (odo, "o.png", "image/png")}
    return c.post("/api/listings", data=data, headers=H, content_type="multipart/form-data")
r = post([png(seed_=1), png(seed_=2), png(seed_=3)], odometer("060000"))
t("post listing works (" + str(r.json.get("odo_read")) + " read by OCR)", r.status_code == 200 and "id" in r.json)
t("odometer OCR read 60000", r.json.get("odo_read") == 60000)
t("photo notes returned for 3 photos", len(r.json["photo_notes"]) == 3)
t("blurred image file saved", os.path.exists(os.path.join(appmod.UPLOADS, f"{r.json['id']}-0.jpg")))
r2 = post([png(seed_=1), png(seed_=5), png(seed_=6)], odometer("060000"), phone="03111111111")
# same first photo but different seller -> need other account
c.post("/api/register", json={"name": "Second User", "email": "two@test.com", "password": "Strong123"})
H2 = {"Authorization": "Bearer " + c.post("/api/login", json={"email": "two@test.com", "password": "Strong123"}).json["token"]}
f = {"model": "Corolla", "year": "2019", "km": "60000", "price": "4300000", "city": "Karachi", "phone": "03222222222"}
r3 = c.post("/api/listings", data={**f, "photos": [(png(seed_=1), "a.png", "image/png"), (png(seed_=7), "b.png", "image/png"), (png(seed_=8), "c.png", "image/png")], "odometer": (odometer("060000"), "o.png", "image/png")}, headers=H2, content_type="multipart/form-data")
t("duplicate photo from another account flagged", any("photo is very similar" in x for x in r3.json["flags"]))
r4 = post([png(seed_=11), png(seed_=12), png(seed_=13)], odometer("120000"), phone="03333333333")
t("odometer mismatch flagged", any("Dashboard photo reads" in x for x in r4.json["flags"]) and r4.json["status"] == "review")
t("only 2 photos rejected", post([png(seed_=1), png(seed_=2)], odometer("060000")).status_code == 400)
t("invalid phone rejected", post([png(seed_=1), png(seed_=2), png(seed_=3)], odometer("060000"), phone="123").status_code == 400)
t("non-image file rejected", c.post("/api/listings", data={**f, "photos": [(io.BytesIO(b"x"), "a.pdf", "application/pdf")] * 3, "odometer": (odometer("060000"), "o.png", "image/png")}, headers=H, content_type="multipart/form-data").status_code == 400)
t("posting requires login", c.post("/api/listings", data=f).status_code == 401)
# --- db status & static pages
s = c.get("/api/db-status").json
t("db-status reports connection and collections", s["connected"] and any(x["name"] == "listings" and x["count"] > 300 for x in s["collections"]))
t("home page served", c.get("/").status_code == 200 and b"AutoFair" in c.get("/").data)
for p in ("signup.html", "login.html", "contact.html", "app.html", "db-status.html", "validation.js", "style.css"):
    t(f"static file {p} served", c.get("/" + p).status_code == 200)
print("\nALL TESTS PASSED" if ok else "\nSOME TESTS FAILED")
sys.exit(0 if ok else 1)
