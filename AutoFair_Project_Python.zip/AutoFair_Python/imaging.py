"""Image analysis: perceptual hash, blur check, car check (YOLO), number-plate blurring, odometer OCR."""
import os
import re
from collections import Counter

import cv2
import numpy as np

_yolo = None
_plate = None


def _yolo_model():
    global _yolo
    if _yolo is None:
        from ultralytics import YOLO
        _yolo = YOLO(os.getenv("YOLO_MODEL", "yolov8n.pt"))  # pretrained COCO model, downloaded on first use
    return _yolo


def _plate_cascade():
    global _plate
    if _plate is None:
        _plate = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_russian_plate_number.xml")
    return _plate


def decode(data):
    return cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)


def dhash(img):
    """64-bit difference hash: survives resize / recolour / light crop (FR-08)."""
    g = cv2.cvtColor(cv2.resize(img, (9, 8), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY).astype(int)
    bits = (g[:, :-1] > g[:, 1:]).flatten()
    return str(int("".join("1" if b else "0" for b in bits), 2))


def analyze(data):
    img = decode(data)
    if img is None:
        raise ValueError("One of the files is not a valid image.")
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    sharp = float(cv2.Laplacian(cv2.resize(gray, (512, 512)), cv2.CV_64F).var())
    is_car, conf = True, 1.0
    if os.getenv("SKIP_CAR_CHECK") != "1":  # FR-14: COCO classes 2 = car, 7 = truck
        boxes = _yolo_model()(img, verbose=False)[0].boxes
        conf = max([float(b.conf) for b in boxes if int(b.cls) in (2, 7)], default=0.0)
        is_car = conf >= float(os.getenv("CAR_CONF", "0.6"))
    out = img.copy()  # FR-13: blur detected number plates
    plates = _plate_cascade().detectMultiScale(gray, 1.1, 4, minSize=(60, 20))
    for x, y, w, h in plates:
        out[y:y + h, x:x + w] = cv2.GaussianBlur(out[y:y + h, x:x + w], (0, 0), max(w, h) / 6)
    _, buf = cv2.imencode(".jpg", out, [cv2.IMWRITE_JPEG_QUALITY, 85])
    return {"phash": dhash(img), "sharpness": sharp, "width": int(img.shape[1]), "is_car": is_car,
            "car_conf": conf, "plates": int(len(plates)), "image": buf.tobytes()}


def read_odometer(data):
    """FR-12: read the odometer digits from a dashboard photo. Returns km (int) or None."""
    import pytesseract
    img = decode(data)
    if img is None:
        raise ValueError("The dashboard photo is not a valid image.")
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if g.shape[1] < 1000:
        g = cv2.resize(g, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    otsu = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    found = []
    for im in (g, otsu, cv2.bitwise_not(otsu)):
        for psm in (7, 6, 11):
            text = pytesseract.image_to_string(im, config=f"--psm {psm} -c tessedit_char_whitelist=0123456789")
            found += re.findall(r"\d{4,7}", text)
    if not found:
        return None
    best = max(Counter(found).most_common(), key=lambda x: (x[1], len(x[0])))[0]
    return int(best)
