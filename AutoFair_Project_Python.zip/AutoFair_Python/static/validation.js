/* AutoFair input validation. One rule set used by BOTH the browser (forms) and the Node server (API). */
(function(root){
const V={};
const EMAIL=/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/, NAME=/^[A-Za-z][A-Za-z .'-]{1,49}$/, PHONE=/^(03\d{9}|\+923\d{9})$/;
V.MODELS=['Corolla','Civic','City','Yaris','Cultus','Alto','Sportage'];
V.CITIES=['Karachi','Lahore','Islamabad','Rawalpindi','Faisalabad'];
const IMG=['image/jpeg','image/png','image/webp'],MAX=8*1024*1024;
const s=x=>(x==null?'':String(x)).trim();
const isInt=x=>/^-?\d+$/.test(s(x));
const email=(o,v)=>{if(!EMAIL.test(v)||v.length>120)o.email='Enter a valid email address (e.g. name@example.com).'};
V.register=d=>{const o={},n=s(d.name),p=d.password==null?'':String(d.password);
 if(!NAME.test(n))o.name="Name must be 2–50 characters: letters, spaces, . ' - only.";
 email(o,s(d.email));
 if(p.length<8||p.length>64||!/[a-z]/.test(p)||!/[A-Z]/.test(p)||!/\d/.test(p))o.password='Password must be 8–64 characters with an uppercase letter, a lowercase letter and a digit.';
 if('confirm' in d&&d.confirm!==p)o.confirm='Passwords do not match.';
 if('terms' in d&&!d.terms)o.terms='You must accept the terms to register.';
 return o};
V.login=d=>{const o={},p=d.password==null?'':String(d.password);email(o,s(d.email));
 if(!p)o.password='Enter your password.';else if(p.length>64)o.password='Password is too long.';return o};
V.contact=d=>{const o={},n=s(d.name),sub=s(d.subject),m=s(d.message),ph=s(d.phone).replace(/[\s-]/g,'');
 if(!NAME.test(n))o.name="Name must be 2–50 characters: letters, spaces, . ' - only.";
 email(o,s(d.email));
 if(ph&&!PHONE.test(ph))o.phone='Phone must look like 03XXXXXXXXX or +923XXXXXXXXX (optional).';
 if(sub.length<3||sub.length>100)o.subject='Subject must be 3–100 characters.';
 if(m.length<10||m.length>1000)o.message='Message must be 10–1000 characters.';
 return o};
V.files=(photos,odo,o)=>{const bad=f=>!IMG.includes(f.type)?'only JPG, PNG or WebP images are allowed':f.size>MAX?'each image must be 8 MB or smaller':f.size===0?'file is empty':'';
 photos=photos||[];odo=odo||[];
 if(photos.length<3||photos.length>6)o.photos='Upload between 3 and 6 car photos.';
 else{const b=photos.map(bad).find(Boolean);if(b)o.photos='Car photos: '+b+'.'}
 if(odo.length!==1)o.odometer='Upload one dashboard photo showing the odometer.';
 else{const b=bad(odo[0]);if(b)o.odometer='Dashboard photo: '+b+'.'}};
V.listing=d=>{const o={},y=new Date().getFullYear();
 if(!V.MODELS.includes(s(d.model)))o.model='Choose a model from the list.';
 if(!isInt(d.year)||+d.year<1990||+d.year>y)o.year='Year must be a whole number between 1990 and '+y+'.';
 if(!isInt(d.km)||+d.km<0||+d.km>1000000)o.km='Mileage must be a whole number between 0 and 1,000,000 km.';
 if(!isInt(d.price)||+d.price<100000||+d.price>200000000)o.price='Price must be a whole number between Rs 100,000 and Rs 200,000,000.';
 if(!V.CITIES.includes(s(d.city)))o.city='Choose a city from the list.';
 if(!PHONE.test(s(d.phone).replace(/[\s-]/g,'')))o.phone='Phone must look like 03XXXXXXXXX or +923XXXXXXXXX.';
 if('photos' in d)V.files(d.photos,d.odometer,o);
 return o};
V.filters=d=>{const o={},y=new Date().getFullYear(),n=k=>s(d[k])!=='';
 [['minp',0,2e8,'Min price'],['maxp',0,2e8,'Max price'],['miny',1990,y,'From year'],['maxy',1990,y,'To year']].forEach(([k,lo,hi,l])=>{if(n(k)&&(!isInt(d[k])||+d[k]<lo||+d[k]>hi))o[k]=`${l} must be a whole number between ${lo} and ${hi}.`});
 if(!o.minp&&!o.maxp&&n('minp')&&n('maxp')&&+d.minp>+d.maxp)o.maxp='Max price must be at least the min price.';
 if(!o.miny&&!o.maxy&&n('miny')&&n('maxy')&&+d.miny>+d.maxy)o.maxy='To year must be at least the from year.';return o};
V.settings=d=>{const o={};[['low_pct',5,60],['km_year',1000,20000],['hash_dist',0,20],['odo_tol',1,20]].forEach(([k,lo,hi])=>{if(d[k]!==undefined&&(!isInt(d[k])||+d[k]<lo||+d[k]>hi))o[k]=`${k} must be a whole number between ${lo} and ${hi}.`});return o};
/* ---- browser helpers ---- */
V.collect=f=>{const d={};[...f.elements].forEach(e=>{if(!e.name)return;d[e.name]=e.type==='checkbox'?e.checked:e.type==='file'?[...e.files]:e.value});return d};
V.show=(f,errs)=>{[...f.elements].forEach(e=>{if(!e.name||e.type==='submit'||e.tagName==='BUTTON')return;let m=e.parentNode.querySelector('.err[data-for="'+e.name+'"]');
 if(!m){m=document.createElement('div');m.className='err';m.dataset.for=e.name;m.setAttribute('role','alert');e.insertAdjacentElement('afterend',m)}
 m.textContent=errs[e.name]||'';e.setAttribute('aria-invalid',errs[e.name]?'true':'false');e.classList.toggle('bad',!!errs[e.name])})};
V.check=(f,fn)=>{const errs=fn(V.collect(f));V.show(f,errs);const k=Object.keys(errs)[0];if(k){const el=f.elements[k];if(el&&el.focus)el.focus();return false}return true};
V.live=(f,fn)=>{const upd=ev=>{if(!ev.target.name)return;const all=fn(V.collect(f)),one={};one[ev.target.name]=all[ev.target.name];
  if(ev.type==='input'&&!ev.target.classList.contains('bad'))return;V.show(f,{...Object.fromEntries([...f.querySelectorAll('.err')].map(m=>[m.dataset.for,m.textContent])),...one,[ev.target.name]:all[ev.target.name]||''})};
 f.addEventListener('blur',upd,true);f.addEventListener('input',upd);f.addEventListener('change',upd)};
if(typeof module!=='undefined'&&module.exports)module.exports=V;else root.V=V;
})(typeof window!=='undefined'?window:this);
