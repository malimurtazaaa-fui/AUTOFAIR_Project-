"""Server-side input validation (same rules as static/validation.js in the browser)."""
import re
from datetime import date

EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
NAME = re.compile(r"[A-Za-z][A-Za-z .'-]{1,49}")
PHONE = re.compile(r"(03\d{9}|\+923\d{9})")
MODELS = ["Corolla", "Civic", "City", "Yaris", "Cultus", "Alto", "Sportage"]
CITIES = ["Karachi", "Lahore", "Islamabad", "Rawalpindi", "Faisalabad"]
IMG_TYPES = {"image/jpeg", "image/png", "image/webp"}
MAX_SIZE = 8 * 1024 * 1024
NAME_MSG = "Name must be 2–50 characters: letters, spaces, . ' - only."


def s(x):
    return "" if x is None else str(x).strip()


def is_int(x):
    return re.fullmatch(r"-?\d+", s(x)) is not None


def _email(o, v):
    if not EMAIL.fullmatch(v) or len(v) > 120:
        o["email"] = "Enter a valid email address (e.g. name@example.com)."


def register(d):
    o, p = {}, d.get("password") or ""
    p = str(p)
    if not NAME.fullmatch(s(d.get("name"))):
        o["name"] = NAME_MSG
    _email(o, s(d.get("email")))
    if not (8 <= len(p) <= 64) or not re.search(r"[a-z]", p) or not re.search(r"[A-Z]", p) or not re.search(r"\d", p):
        o["password"] = "Password must be 8–64 characters with an uppercase letter, a lowercase letter and a digit."
    return o


def login(d):
    o, p = {}, str(d.get("password") or "")
    _email(o, s(d.get("email")))
    if not p:
        o["password"] = "Enter your password."
    elif len(p) > 64:
        o["password"] = "Password is too long."
    return o


def contact(d):
    o = {}
    ph = re.sub(r"[\s-]", "", s(d.get("phone")))
    if not NAME.fullmatch(s(d.get("name"))):
        o["name"] = NAME_MSG
    _email(o, s(d.get("email")))
    if ph and not PHONE.fullmatch(ph):
        o["phone"] = "Phone must look like 03XXXXXXXXX or +923XXXXXXXXX (optional)."
    if not 3 <= len(s(d.get("subject"))) <= 100:
        o["subject"] = "Subject must be 3–100 characters."
    if not 10 <= len(s(d.get("message"))) <= 1000:
        o["message"] = "Message must be 10–1000 characters."
    return o


def _bad_file(f):
    if f["type"] not in IMG_TYPES:
        return "only JPG, PNG or WebP images are allowed"
    if f["size"] > MAX_SIZE:
        return "each image must be 8 MB or smaller"
    if f["size"] == 0:
        return "file is empty"
    return ""


def files(photos, odo, o):
    if not 3 <= len(photos) <= 6:
        o["photos"] = "Upload between 3 and 6 car photos."
    else:
        b = next((x for x in map(_bad_file, photos) if x), "")
        if b:
            o["photos"] = "Car photos: " + b + "."
    if len(odo) != 1:
        o["odometer"] = "Upload one dashboard photo showing the odometer."
    else:
        b = _bad_file(odo[0])
        if b:
            o["odometer"] = "Dashboard photo: " + b + "."


def listing(d):
    o, y = {}, date.today().year
    if s(d.get("model")) not in MODELS:
        o["model"] = "Choose a model from the list."
    if not is_int(d.get("year")) or not 1990 <= int(s(d["year"])) <= y:
        o["year"] = f"Year must be a whole number between 1990 and {y}."
    if not is_int(d.get("km")) or not 0 <= int(s(d["km"])) <= 1000000:
        o["km"] = "Mileage must be a whole number between 0 and 1,000,000 km."
    if not is_int(d.get("price")) or not 100000 <= int(s(d["price"])) <= 200000000:
        o["price"] = "Price must be a whole number between Rs 100,000 and Rs 200,000,000."
    if s(d.get("city")) not in CITIES:
        o["city"] = "Choose a city from the list."
    if not PHONE.fullmatch(re.sub(r"[\s-]", "", s(d.get("phone")))):
        o["phone"] = "Phone must look like 03XXXXXXXXX or +923XXXXXXXXX."
    if "photos" in d:
        files(d["photos"], d.get("odometer", []), o)
    return o


def settings(d):
    o = {}
    for k, lo, hi in (("low_pct", 5, 60), ("km_year", 1000, 20000), ("hash_dist", 0, 20), ("odo_tol", 1, 20)):
        if d.get(k) is not None and (not is_int(d[k]) or not lo <= int(s(d[k])) <= hi):
            o[k] = f"{k} must be a whole number between {lo} and {hi}."
    return o
