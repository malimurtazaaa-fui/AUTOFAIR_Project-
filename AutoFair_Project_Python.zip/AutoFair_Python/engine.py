"""Price-fairness engine + suspicious-ad rules (FR-04..FR-08, FR-12)."""
from datetime import date
from statistics import median as _median
from db import col

DEFAULTS = {"low_pct": 30, "km_year": 5000, "hash_dist": 10, "odo_tol": 5}


def get_settings():
    s = col("settings").find_one({"_id": "main"}) or {}
    return {k: s.get(k, v) for k, v in DEFAULTS.items()}


def rate(ratio, s):
    if ratio < 1 - s["low_pct"] / 100:
        return "Low"
    if ratio <= 0.9:
        return "Good"
    return "Fair" if ratio <= 1.1 else "Over"


def hamming(a, b):
    return bin(int(a) ^ int(b)).count("1")  # number of different bits between two 64-bit hashes


def owner(o):
    """Seeded demo ads have no seller_id: each one counts as its own seller."""
    return o["seller_id"] if o.get("seller_id") is not None else -o["id"]


def evaluate(l, hashes=()):
    """l: dict with model, year, km, price, phone (+ id, seller_id, odo_read if known)."""
    s, lid, flags = get_settings(), l.get("id", 0), []
    key = owner({"seller_id": l.get("seller_id"), "id": lid})
    lo = (l["km"] // 20000) * 20000
    comps = list(col("listings").find(
        {"id": {"$ne": lid}, "status": {"$ne": "removed"}, "model": l["model"],
         "year": {"$gte": l["year"] - 1, "$lte": l["year"] + 1}, "km": {"$gte": lo, "$lt": lo + 20000}},
        {"_id": 0, "id": 1, "year": 1, "km": 1, "price": 1}))
    rating, med, ratio = "NA", None, None
    if len(comps) >= 5:
        med = _median(c["price"] for c in comps)
        ratio = l["price"] / med
        rating = rate(ratio, s)
        if rating == "Low":
            flags.append(f"Price is {round((1 - ratio) * 100)}% below the median of similar cars (limit {s['low_pct']}%).")
    age = max(1, date.today().year - l["year"])
    if l["km"] / age < s["km_year"]:
        flags.append(f"Only {round(l['km'] / age)} km per year (limit {s['km_year']}). Odometer may be tampered with.")
    if l.get("phone"):
        same = col("listings").find({"id": {"$ne": lid}, "status": {"$ne": "removed"}, "phone": l["phone"]},
                                    {"_id": 0, "id": 1, "seller_id": 1})
        if any(owner(o) != key for o in same):
            flags.append("Same phone number is used on listings from a different account.")
    if hashes:
        photos = list(col("photos").find({"listing_id": {"$ne": lid}}, {"_id": 0, "listing_id": 1, "phash": 1}))
        if photos:
            ids = list({p["listing_id"] for p in photos})
            ok = {o["id"] for o in col("listings").find({"id": {"$in": ids}, "status": {"$ne": "removed"}},
                                                         {"_id": 0, "id": 1, "seller_id": 1}) if owner(o) != key}
            if any(p["listing_id"] in ok and hamming(p["phash"], h) <= s["hash_dist"] for p in photos for h in hashes):
                flags.append("A photo is very similar (perceptual hash) to a photo on another account's listing.")
    if "odo_read" in l:  # only for ads posted with a dashboard photo
        if l["odo_read"] is None:
            flags.append("Mileage could not be read from the dashboard photo.")
        elif abs(l["odo_read"] - l["km"]) / max(l["km"], 1) * 100 > s["odo_tol"]:
            flags.append(f"Dashboard photo reads {l['odo_read']} km but listing says {l['km']} km (tolerance {s['odo_tol']}%).")
    return {"rating": rating, "median": med, "ratio": ratio, "comps": comps, "flags": flags}
